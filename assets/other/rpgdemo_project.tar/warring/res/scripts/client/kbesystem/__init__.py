# -*- coding: utf-8 -*-
#
"""
"""
from KBEDebug import *
from kbesystem.TargetMgr import TargetMgr
from kbesystem.event import *

targetMgr = TargetMgr()
