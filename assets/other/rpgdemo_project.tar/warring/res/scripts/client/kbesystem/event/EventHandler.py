# -*- coding: utf-8 -*-
import KBEngine
import KBExtra
from KBEDebug import *

class EventHandler:
	def __init__(self):
		pass
		
	def onEvent(self, event, *args):
		"""
		virtual method.
		发生事件
		"""
		pass
