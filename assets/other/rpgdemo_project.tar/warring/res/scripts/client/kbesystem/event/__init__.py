# -*- coding: utf-8 -*-
#
"""
"""
from KBEDebug import *
from kbesystem.event.EventMgr import EventMgr

eventMgr = EventMgr()