# -*- coding: utf-8 -*-
import KBEngine
from KBEDebug import * 

class Teleport:
	def __init__(self):
		pass


