# -*- coding: utf-8 -*-
#
"""
"""
from KBEDebug import *

def onInit():
	"""
	init skills.
	"""
	pass

