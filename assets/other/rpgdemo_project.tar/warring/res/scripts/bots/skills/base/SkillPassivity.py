# -*- coding: utf-8 -*-
import KBEngine
from KBEDebug import * 
from skillbases.SObject import SObject

class SkillPassivity(SObject):
	def __init__(self):
		SObject.__init__(self)
