# -*- coding: utf-8 -*-
#
"""
"""
from KBEDebug import *

def onInit():
	"""
	init items.
	"""
	pass

