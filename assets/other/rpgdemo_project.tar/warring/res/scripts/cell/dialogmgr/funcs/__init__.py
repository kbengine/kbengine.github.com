# -*- coding: utf-8 -*-
#
"""
"""

from dialogmgr.funcs.DFTeleport import DFTeleport
from dialogmgr.funcs.DFClose import DFClose

g_funcs = {
	"teleport" : DFTeleport,
	"closedialog" : DFClose,
}
