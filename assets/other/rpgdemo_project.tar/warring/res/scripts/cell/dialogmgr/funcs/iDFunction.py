# -*- coding: utf-8 -*-
#
"""
"""

class iDFunction:
	"""
	"""
	def __init__(self, args):
		pass

	def valid(self, avatar, args):
		return True

	def do(self, avatar, args):
		return True