# -*- coding: utf-8 -*-

datas={1: {'entities': (1001, 1002, 1003), 'entityType': 'Space', 'type': 1, 'name': '新手村', 'id': 1, 'resPath' : "xinshoucun"}, 2: {'entities': (2001, 2002, 2003), 'entityType': 'SpaceCopy', 'type': 2, 'name': '副本战地', 'id': 2, 'resPath' : ""}}

allDatas = {
	'场景表':datas,
}