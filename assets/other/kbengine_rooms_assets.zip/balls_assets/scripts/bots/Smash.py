# -*- coding: utf-8 -*-
import KBEngine
import KBExtra
from KBEDebug import *

class Smash(KBEngine.Entity):
	def __init__(self):
		KBEngine.Entity.__init__(self)
