# -*- coding: utf-8 -*-
import KBEngine
from KBEDebug import *

class Player(KBEngine.Entity):
	def __init__(self):
		KBEngine.Entity.__init__(self)
		DEBUG_MSG("Player::__init__:%s." % (self.__dict__))
