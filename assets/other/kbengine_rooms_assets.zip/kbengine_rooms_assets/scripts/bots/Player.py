# -*- coding: utf-8 -*-
import KBEngine
from KBEDebug import *

class Player(KBEngine.Entity):
	def __init__(self):
		KBEngine.Entity.__init__(self)
		DEBUG_MSG("Player::__init__:%s." % (self.__dict__))
		self.base.reqGetHallsCount()
		self.base.reqEnterHall(3)
		self.base.reqEnterRoom(3000)		
		self.base.reqStartGame()
		self.base.say(str(self.id))
		self.base.reqStopGame()
		self.base.reqLeaveRoom()
		self.base.reqLeaveHall()

		self.base.reqEnumHalls()
		self.base.reqEnumRooms(3)
		
	def onGetHallsCount(self, count):
		"""
		defined method.
		收到大厅数量
		"""
		DEBUG_MSG("Player:onGetHallsCount:: count=%i" % (count))

	def onEnumHalls(self, hallsInfos):
		"""
		defined method.
		收到枚举的大厅， 可能会多次回调
		"""
		for infos in hallsInfos:
			DEBUG_MSG("Player:onEnumHalls:: name=%s, id=%i, rooms_count=%i, players_count=%i" % \
				(infos["name"], infos["id"], infos["rooms_count"], infos["players_count"]))
		
	def onEnumRooms(self, roomsInfos):
		"""
		defined method.
		收到枚举的房间， 可能会多次回调
		"""
		for infos in roomsInfos:
			DEBUG_MSG("Player:onEnumRooms:: name=%s, id=%i, players_count=%i, state=%i" % \
				(infos["name"], infos["id"], infos["players_count"], infos["state"]))
					
	def onSay(self, str):
		"""
		defined method.
		收到聊天信息
		"""
		DEBUG_MSG("Player:onSay:: str=%s" % (str))