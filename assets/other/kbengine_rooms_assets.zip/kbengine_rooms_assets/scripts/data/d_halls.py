# -*- coding: utf-8 -*-

datas={
	1:
		{
			"id" : 1,
			"hallName" : "hall1",
			"roomCount" : 5,
		},
		
	2:
		{
			"id" : 2,
			"hallName" : "hall2",
			"roomCount" : 5,
		},
		
	3:
		{
			"id" : 3,
			"hallName" : "hall3",
			"roomCount" : 5,
		},
		
	4:
		{
			"id" : 4,
			"hallName" : "hall4",
			"roomCount" : 5,
		},
		
	5:
		{
			"id" : 5,
			"hallName" : "hall5",
			"roomCount" : 5,
		},								
}