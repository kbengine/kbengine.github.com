# -*- coding: utf-8 -*-
import KBEngine
import random
import time
import d_halls
import GlobalConst
from KBEDebug import *

class Halls(KBEngine.Base):
	"""
	大厅管理器实体
	该实体管理该服务组上所有的大厅
	"""
	def __init__(self):
		KBEngine.Base.__init__(self)
		
		# 将自己注册到共享数据中， 在当前进程KBEngine.globalData["Halls"]返回的是Halls实体，其他进程中
		# 由于实体不在那个进程所以KBEngine.globalData["Halls"]返回的是mailbox
		# 因此调用KBEngine.globalData["Halls"].xxx方法必须在def定义，允许远程访问
		KBEngine.globalData["Halls"] = self
		
		# 存放所有大厅信息与mailbox
		self.halls = {}
		
		# 通过添加一个定时器延时执行大厅的创建，确保一些状态在此期间能够初始化完毕
		self.addTimer(3, 0, 1)
		
	def _createHalls(self):
		"""
		根据配置创建出所有的大厅
		"""
		for infos in d_halls.datas.values():
			KBEngine.createBaseAnywhere("Hall", 
											{"hallID" : infos["id"],	\
											})
														
	def addHall(self, id, mailbox):
		"""
		defined.
		向大厅管理器添加大厅
		"""
		self.halls[id] = mailbox
		
	def removeHall(self, id):
		"""
		defined.
		向大厅管理器添加大厅
		"""
		del self.halls[id]
				
	def onTimer(self, id, userArg):
		"""
		KBEngine method.
		使用addTimer后， 当时间到达则该接口被调用
		@param id		: addTimer 的返回值ID
		@param userArg	: addTimer 最后一个参数所给入的数据
		"""
		DEBUG_MSG(id, userArg)

		if userArg == 1:
			self._createHalls()
			
	def reqGetHallsCount(self, player):
		"""
		defined.
		客户端调用该接口请求获得房间数量
		"""
		DEBUG_MSG("Halls[%i].reqGetHallsCount" % (self.id))
		player.client.onGetHallsCount(len(self.halls))
				
	def reqEnumHalls(self, player):
		"""
		defined.
		客户端调用该接口请求枚举列出所有大厅
		"""
		DEBUG_MSG("Halls[%i].reqEnumHalls" % (self.id))
		for hall in self.halls.values():
			hall.reqEnumHall(player)
		
	def reqEnumRooms(self, player, hallID):
		"""
		defined.
		客户端调用该接口请求枚举列出所有房间/桌子
		"""
		DEBUG_MSG("Halls[%i].reqEnumRooms: %s" % (self.id, hallID))
		self.halls[hallID].reqEnumRooms(player)
		
	def reqEnterHall(self, player, hallID):
		"""
		defined.
		客户端调用该接口请求进入大厅
		"""
		DEBUG_MSG("Halls[%i].reqEnterHall: %s" % (self.id, hallID))
		self.halls[hallID].reqEnterHall(player)
		
	def reqLeaveHall(self, player, hallID):
		"""
		defined.
		客户端调用该接口请求离开大厅
		"""
		DEBUG_MSG("Halls[%i].reqLeaveHall: %s" % (self.id, hallID))
		self.halls[hallID].reqLeaveHall(player)
		
	def reqEnterRoom(self, player, hallID, roomID):
		"""
		defined.
		客户端调用该接口请求进入房间/桌子
		"""
		DEBUG_MSG("Halls[%i].reqEnterRoom: %s" % (self.id, roomID))
		self.halls[hallID].reqEnterRoom(player, roomID)
		
	def reqLeaveRoom(self, player, hallID, roomID):
		"""
		defined.
		客户端调用该接口请求离开房间/桌子
		"""
		DEBUG_MSG("Halls[%i].reqLeaveRoom: %s" % (self.id, roomID))
		self.halls[hallID].reqLeaveRoom(player, roomID)
		
	def reqStartGame(self, player, hallID, roomID):
		"""
		defined.
		客户端调用该接口请求开始游戏
		"""
		DEBUG_MSG("Halls[%i].reqStartGame: %s" % (self.id, roomID))
		self.halls[hallID].reqStartGame(player, roomID)
		
	def reqStopGame(self, player, hallID, roomID):
		"""
		defined.
		客户端调用该接口请求停止游戏
		"""
		DEBUG_MSG("Halls[%i].reqStopGame: %s" % (self.id, roomID))
		self.halls[hallID].reqStopGame(player, roomID)
						
	def say(self, player, hallID, roomID, str):
		"""
		defined.
		说话的内容
		"""
		DEBUG_MSG("Halls[%i].say: %s" % (self.id, str))
		self.halls[hallID].say(player, roomID, str)