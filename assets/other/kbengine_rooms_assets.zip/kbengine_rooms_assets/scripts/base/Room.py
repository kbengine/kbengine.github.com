# -*- coding: utf-8 -*-
import KBEngine
import random
import time
import d_halls
import GlobalConst
from KBEDebug import *

class Room:
	"""
	这是一个游戏房间/桌子类
	该类处理维护一个房间中的实际游戏， 例如：斗地主、麻将等
	该房间中记录了房间里所有玩家的mailbox，通过mailbox我们可以将信息推送到他们的客户端。
	"""
	def __init__(self, roomID, name):
		self.roomID = roomID
		self.roomName = name
		
		# 状态0：未开始游戏， 1：游戏中
		self.state = 0
		
		# 存放该房间内的玩家mailbox
		self.players = {}
	
	def reqEnterRoom(self, player):
		"""
		defined.
		客户端调用该接口请求进入房间/桌子
		"""
		DEBUG_MSG("Room.reqEnterRoom: %s" % (self.roomID))
		self.players[player.id] = player
		
	def reqLeaveRoom(self, player):
		"""
		defined.
		客户端调用该接口请求离开房间/桌子
		"""
		DEBUG_MSG("Room.reqLeaveRoom: %s" % (self.roomID))
		del self.players[player.id]
		
	def reqStartGame(self, player):
		"""
		defined.
		客户端调用该接口请求开始游戏
		"""
		DEBUG_MSG("Room.reqLeaveRoom: %s" % (self.roomID))
		self.state = 1
		
	def reqStopGame(self, player):
		"""
		客户端调用该接口请求停止游戏
		"""
		DEBUG_MSG("Room.reqLeaveRoom: %s" % (self.roomID))
		self.state = 0
						
	def say(self, player, str):
		"""
		说话的内容
		"""
		DEBUG_MSG("Room.Player[%i].say: %s" % (self.roomID, str))
		for mb in self.players.values():
			mb.client.onSay(str)
					
						
