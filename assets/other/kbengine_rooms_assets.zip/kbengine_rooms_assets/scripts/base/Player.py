# -*- coding: utf-8 -*-
import KBEngine
import random
import time
import d_halls
import GlobalConst
from KBEDebug import *

class Player(KBEngine.Proxy):
	"""
	玩家实体
	客户端登陆到服务端后，服务端将自动创建这个实体，通过这个实体与客户端进行交互
	"""
	def __init__(self):
		KBEngine.Proxy.__init__(self)
		
		# 玩家当前所在大厅
		self.hallID = 0
		
		# 玩家当前所在房间
		self.roomID = 0
		
	def onTimer(self, id, userArg):
		"""
		KBEngine method.
		使用addTimer后， 当时间到达则该接口被调用
		@param id		: addTimer 的返回值ID
		@param userArg	: addTimer 最后一个参数所给入的数据
		"""
		DEBUG_MSG(id, userArg)
		
	def onEntitiesEnabled(self):
		"""
		KBEngine method.
		该entity被正式激活为可使用， 此时entity已经建立了client对应实体， 可以在此创建它的
		cell部分。
		"""
		INFO_MSG("Account[%i]::onEntitiesEnabled:entities enable. mailbox:%s, clientType(%i), clientDatas=(%s), accountName=%s" % \
			(self.id, self.client, self.getClientType(), self.getClientDatas(), self.__ACCOUNT_NAME__))
			
	def onLogOnAttempt(self, ip, port, password):
		"""
		KBEngine method.
		客户端登陆失败时会回调到这里
		"""
		INFO_MSG("Account[%i]::onLogOnAttempt: ip=%s, port=%i, selfclient=%s" % (self.id, ip, port, self.client))			
		return KBEngine.LOG_ON_ACCEPT
		
	def onClientDeath(self):
		"""
		KBEngine method.
		客户端对应实体已经销毁
		"""
		DEBUG_MSG("Account[%i].onClientDeath:" % self.id)
		
		# 先退出大厅，退出大厅功能中应该能确保后续所有的事情
		# 玩家在游戏中或者其他状态应该如何处理
		self.reqLeaveHall()
		
		self.destroy()
	
	def reqGetHallsCount(self):
		"""
		exposed.
		客户端调用该接口请求获得房间数量
		"""
		DEBUG_MSG("Player[%i].reqGetHallsCount" % (self.id))
		KBEngine.globalData["Halls"].reqGetHallsCount(self)
				
	def reqEnumHalls(self):
		"""
		exposed.
		客户端调用该接口请求枚举列出所有大厅
		"""
		DEBUG_MSG("Player[%i].reqEnumHalls" % (self.id))
		KBEngine.globalData["Halls"].reqEnumHalls(self)
		
	def reqEnumRooms(self, hallID):
		"""
		exposed.
		客户端调用该接口请求枚举列出所有房间/桌子
		"""
		DEBUG_MSG("Player[%i].reqEnumRooms: %s" % (self.id, hallID))
		KBEngine.globalData["Halls"].reqEnumRooms(self, hallID)
		
	def reqEnterHall(self, hallID):
		"""
		exposed.
		客户端调用该接口请求进入大厅
		应该做一系列的检查，如果玩家已经在大厅或者其他情况怎么处理？
		"""
		assert self.hallID == 0
		DEBUG_MSG("Player[%i].reqEnterHall: %s" % (self.id, hallID))
		
		# 此处在逻辑复杂后需要考虑安全问题，例如进入大厅失败
		self.hallID = hallID
		
		KBEngine.globalData["Halls"].reqEnterHall(self, hallID)
		
	def reqLeaveHall(self):
		"""
		exposed.
		客户端调用该接口请求离开大厅
		退出大厅功能中应该能确保后续所有的事情
		玩家在游戏中或者其他状态应该如何处理？	
		"""
		if self.hallID == 0:
			return
			
		DEBUG_MSG("Player[%i].reqLeaveHall: %s" % (self.id, self.hallID))
		KBEngine.globalData["Halls"].reqLeaveHall(self, self.hallID)
						
		# 此处在逻辑复杂后需要考虑安全问题，例如离开大厅失败
		self.hallID = 0
								
	def reqEnterRoom(self, roomID):
		"""
		exposed.
		客户端调用该接口请求进入房间/桌子
		应该做一系列的检查，如果玩家已经在房间或者其他情况怎么处理？
		"""
		assert self.roomID == 0
		DEBUG_MSG("Player[%i].reqEnterRoom: %s" % (self.id, roomID))
		
		# 此处在逻辑复杂后需要考虑安全问题，例如进入房间失败
		self.roomID = roomID
				
		KBEngine.globalData["Halls"].reqEnterRoom(self, self.hallID, roomID)
		
	def reqLeaveRoom(self):
		"""
		exposed.
		客户端调用该接口请求离开房间/桌子
		退出房间功能中应该能确保后续所有的事情
		玩家在游戏中或者其他状态应该如何处理？	
		"""
		if self.roomID == 0:
			return
			
		DEBUG_MSG("Player[%i].reqLeaveRoom: %s" % (self.id, self.roomID))
		KBEngine.globalData["Halls"].reqLeaveRoom(self, self.hallID, self.roomID)
		
		# 此处在逻辑复杂后需要考虑安全问题，例如离开房间失败
		self.roomID = 0
				
	def reqStartGame(self):
		"""
		exposed.
		客户端调用该接口请求开始游戏
		"""
		if self.roomID == 0:
			return
		
		# 游戏状态在房间中，需要去房间判断，那么就是说这个接口调用后不一定成功开始，那么失败了该如何？
		# 失败可以做一个失败回调或者直接通知客户端“正在游戏中”
		DEBUG_MSG("Player[%i].reqStartGame: %s" % (self.id, self.roomID))
		KBEngine.globalData["Halls"].reqStartGame(self, self.hallID, self.roomID)
		
	def reqStopGame(self):
		"""
		exposed.
		客户端调用该接口请求停止游戏
		"""
		if self.roomID == 0:
			return
		
		# 游戏状态在房间中，需要去房间判断，那么就是说这个接口调用后不一定成功开始，那么失败了该如何？
		# 失败可以做一个失败回调或者直接通知客户端“没有正在进行的游戏”					
		DEBUG_MSG("Player[%i].reqStopGame: %s" % (self.id, self.roomID))
		KBEngine.globalData["Halls"].reqStopGame(self, self.hallID, self.roomID)
						
	def say(self, str):
		"""
		exposed.
		说话的内容
		"""
		if self.hallID == 0 and self.roomID == 0:
			return
					
		DEBUG_MSG("Player[%i].say: %s" % (self.id, str))
		KBEngine.globalData["Halls"].say(self, self.hallID, self.roomID, str)