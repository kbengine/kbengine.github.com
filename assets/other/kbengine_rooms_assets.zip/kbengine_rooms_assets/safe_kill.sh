#!/bin/sh

python ../kbe/tools/server/pycluster/cluster_controller.py stop